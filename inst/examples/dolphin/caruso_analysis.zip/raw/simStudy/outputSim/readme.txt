This folder must be filled with RData files contained in the folder "outputSim" 
(link to the folder: https://drive.google.com/drive/folders/1OMiyAP8iupf6FD_vOhSL_aI9woP9HsD7?usp=sharing)